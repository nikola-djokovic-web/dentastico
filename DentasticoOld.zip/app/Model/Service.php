<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
  public $table = 'services';

  public $fillable = ['title','title2','title3','description','content','content2','content3','image'];


  public function serviceUrl(){
      return route('single-service', [
          'id' => $this->id,
          'slug' => str_slug($this->title)
      ]);
  }

  public function serviceUrlEn(){
      return route('single-service', [
          'id' => $this->id,
          'slug' => str_slug($this->title2)
      ]);
  }

  public function serviceUrlIt(){
      return route('single-service', [
          'id' => $this->id,
          'slug' => str_slug($this->title3)
      ]);
  }
}
