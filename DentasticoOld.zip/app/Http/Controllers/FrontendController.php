<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Service;

class FrontendController extends Controller
{
    public function services(){
      return view('frontend.pages.services');
    }

    public function about(){
      return view('frontend.pages.about');
    }

    public function contact(){
      return view('frontend.pages.contact');
    }

    public function singleService(Service $service){
      $data = Service::orderBy('created_at', 'DESC')->get();
      return view('frontend.pages.single-service', compact('data', 'service'));
    }
}
