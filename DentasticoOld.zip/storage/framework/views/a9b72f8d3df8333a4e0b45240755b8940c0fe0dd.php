<header class="top_panel_wrap top_panel_style_2 scheme_original">
    <div class="top_panel_wrap_inner top_panel_inner_style_2 top_panel_position_above">
        <div class="top_panel_middle">
            <div class="content_wrap">
                <div class="columns_wrap columns_fluid">
                    <div class="column-1_3 contact_field contact_phone_wrap">
                        <span class="contact_icon icon-phone"></span>
                        <span class="contact_label contact_phone">Free Call <strong>+1 800 125 65 24</strong></span>
                        <span class="contact_address">528 tenth Avenue, Boston, BT 58965</span>
                    </div>
                    <div class="column-1_3 contact_logo">
                        <div class="logo">
                            <a href="index.html">
                                <img src="/templates/frontend/images/logo-1x.png" class="logo_main" alt="" width="202" height="49">
                            </a>
                        </div>
                    </div>
                    <div class="column-1_3 contact_field open_hours_wrap">
                        <!-- <span class="contact_icon icon-calendar-light"></span>
                        <span class="open_hours_label">Open hours:</span>
                        <span class="open_hours_text">Mn - St: <strong>8:00am - 9:00pm</strong> Sn: Closed</span> -->

                        <div class="nav-wrapper">
                          <div class="sl-nav">
                            <!-- Sprache: -->
                            <ul>
                              <li><b>Language</b> <i class="fa fa-angle-down" aria-hidden="true"></i>
                                <div class="triangle"></div>
                                <ul>
                                  <li><i class="sl-flag flag-de"><div id="serbian"></div></i> <span>Srpski</span></li>
                                  <li><i class="sl-flag flag-de"><div id="germany"></div></i> <span class="active">Deutsch</span></li>
                                  <li><i class="sl-flag flag-usa"><div id="english"></div></i> <span>Englisch</span></li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="top_panel_bottom">
            <div class="content_wrap clearfix">
                <nav class="menu_main_nav_area">
                    <ul id="menu_main" class="menu_main_nav">
                        <li class="menu-item <?php echo e(isActiveRoute('homepage')); ?>"><a href="<?php echo e(route('homepage')); ?>"><span>Home</span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('services')); ?>"><a href="<?php echo e(route('services')); ?>"><span>Services</span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('about')); ?>"><a href="<?php echo e(route('about')); ?>"><span>About</span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('contact')); ?>"><a href="<?php echo e(route('contact')); ?>"><span>Contacts</span></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<div class="header_mobile">
    <div class="content_wrap">
        <div class="menu_button icon-menu"></div>
        <div class="logo">
            <a href="index.html">
                <img src="/templates/frontend/images/logo-1x.png" class="logo_main" alt="" width="202" height="49">
            </a>
        </div>
    </div>
    <div class="side_wrap">
        <div class="close">Close</div>
        <div class="panel_top">
            <nav class="menu_main_nav_area">
                <ul id="menu_main_mobile" class="menu_main_nav">
                    <li class="menu-item current-menu-ancestor current-menu-parent menu-item-has-children"><a href="#"><span>Home</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="index.html"><span>Home 1</span></a></li>
                            <li class="menu-item"><a href="home-2.html"><span>Home 2</span></a></li>
                            <li class="menu-item current-menu-item"><a href="home-3.html"><span>Home 3</span></a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="#"><span>Pages</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="typography.html"><span>Typography</span></a></li>
                            <li class="menu-item"><a href="shortcodes.html"><span>Shortcodes</span></a></li>
                            <li class="menu-item"><a href="pricing.html"><span>Pricing</span></a></li>
                            <li class="menu-item"><a href="customization.html"><span>Customization</span></a></li>
                            <li class="menu-item"><a href="support.html"><span>Support</span></a></li>
                            <li class="menu-item"><a href="shop.html"><span>Shop</span></a></li>
                            <li class="menu-item"><a href="faq.html"><span>FAQ</span></a></li>
                            <li class="menu-item"><a href="404.html"><span>Error 404</span></a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="services.html"><span>Services</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="single-service.html"><span>Service Single</span></a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="#"><span>About</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="about.html"><span>About Us</span></a></li>
                            <li class="menu-item"><a href="team.html"><span>Our Team</span></a></li>
                            <li class="menu-item"><a href="single-team.html"><span>Dentist&#8217;s Profile</span></a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="#"><span>Gallery</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="grid.html"><span>Grid</span></a></li>
                            <li class="menu-item"><a href="masonry.html"><span>Masonry</span></a></li>
                            <li class="menu-item"><a href="cobbles.html"><span>Cobbles</span></a></li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="#"><span>News</span></a>
                        <ul class="sub-menu">
                            <li class="menu-item"><a href="post-formats.html"><span>Post Formats</span></a></li>
                            <li class="menu-item"><a href="classic.html"><span>Classic</span></a></li>
                            <li class="menu-item menu-item-has-children"><a href="#"><span>Masonry</span></a>
                                <ul class="sub-menu">
                                    <li class="menu-item"><a href="masonry-2-columns.html"><span>Masonry (2 columns)</span></a></li>
                                    <li class="menu-item"><a href="masonry-3-columns.html"><span>Masonry (3 columns)</span></a></li>
                                </ul>
                            </li>
                            <li class="menu-item menu-item-has-children"><a href="#"><span>Portfolio</span></a>
                                <ul class="sub-menu">
                                    <li class="menu-item"><a href="portfolio-2-columns.html"><span>Portfolio (2 columns)</span></a></li>
                                    <li class="menu-item"><a href="portfolio-3-columns.html"><span>Portfolio (3 columns)</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item"><a href="appointment.html"><span>Appointment</span></a></li>
                    <li class="menu-item"><a href="contacts.html"><span>Contacts</span></a></li>
                </ul>
            </nav>
            <div class="search_wrap search_style_regular search_state_fixed search_ajax">
                <div class="search_form_wrap">
                    <form role="search" method="get" class="search_form" action="#">
                        <input type="text" class="search_field" placeholder="Search" value="" name="s" />
                        <button type="submit" class="search_submit icon-magnifying-glass-2" title="Start search"></button>
                    </form>
                </div>
                <div class="search_results widget_area scheme_original">
                    <a class="search_results_close icon-cancel"></a>
                    <div class="search_results_content"></div>
                </div>
            </div>
            <div class="login">
                <a href="#popup_login" class="popup_link popup_login_link icon-user">Login</a>
            </div>
        </div>
        <div class="panel_bottom">
            <div class="contact_socials">
                <div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_small">
                    <div class="sc_socials_item">
                        <a href="#" target="_blank" class="social_icons social_twitter">
                            <span class="icon-twitter"></span>
                        </a>
                    </div>
                    <div class="sc_socials_item">
                        <a href="#" target="_blank" class="social_icons social_gplus">
                            <span class="icon-gplus"></span>
                        </a>
                    </div>
                    <div class="sc_socials_item">
                        <a href="#" target="_blank" class="social_icons social_facebook">
                            <span class="icon-facebook"></span>
                        </a>
                    </div>
                    <div class="sc_socials_item">
                        <a href="#" target="_blank" class="social_icons social_digg">
                            <span class="icon-digg"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mask"></div>
</div>
