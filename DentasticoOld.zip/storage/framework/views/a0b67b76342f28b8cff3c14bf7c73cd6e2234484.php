<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="top_panel_title top_panel_style_2 title_present breadcrumbs_present scheme_original">
    <div class="top_panel_title_inner top_panel_inner_style_2  title_present_inner breadcrumbs_present_inner">
        <div class="content_wrap">
            <h1 class="page_title">Services</h1>
            <div class="breadcrumbs">
                <a class="breadcrumbs_item home" href="index.html">Home</a>
                <span class="breadcrumbs_delimiter"></span>
                <span class="breadcrumbs_item current">Services</span>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page_content_wrap page_paddings_yes">
  <div class="content_wrap">
    <div class="content">
        <article class="post_item post_item_single page hentry">
            <section class="post_content">
                <div class="vc_row wpb_row vc_row-fluid">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div id="sc_services_620_wrap" class="sc_services_wrap">
                                    <div id="sc_services_620" class="sc_services sc_services_style_services-1 sc_services_type_icons margin_top_null margin_bottom_large">
                                        <h2 class="sc_services_title sc_item_title">Our Clinic Services</h2>
                                        <div class="sc_services_descr sc_item_descr">Most demanded services</div>
                                        <div class="sc_columns columns_wrap">
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_1" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-3"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Tooth Protection</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_2" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-1"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Dental Implants</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>The implant fixture is first placed, so that it is likely to osseointegrate, then a dental prosthetic is added</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_3" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-3"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Dental Care</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>We provide a wide range of oral health care services to patients, from routine checkups to fitting braces</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_4" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-12"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Teeth Whitening</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>Bleaching methods use carbamide peroxide which reacts with water to form hydrogen peroxide loremis</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_5" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-8"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Dental Calculus</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>Types of bridges may vary, depending upon how they are fabricated and the way they anchor to the adjacent teeth</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="column-1_3 column_padding_bottom">
                                                <div id="sc_services_620_6" class="sc_services_item">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-6"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Prevention</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>The most important part of preventive dentistry is to brush teeth with fluoride toothpaste approved by ADA</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1455033114246">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                    <div class="column-1_2 sc_column_item">
                                        <div class="sc_section margin_top_huge margin_bottom_huge">
                                            <div class="sc_section_inner">
                                                <h3 class="sc_title sc_title_regular">
                                                    We eliminate the inconvenience<br /> of multiple visits
                                                </h3>
                                                <ul class="sc_list sc_list_style_iconed">
                                                    <li class="sc_list_itemt" title="No second injections or temporaries">
                                                        <span class="sc_list_icon icon-ok"></span>No second injections or temporaries
                                                    </li>
                                                    <li class="sc_list_item" title="No unprofessional doctors">
                                                        <span class="sc_list_icon icon-ok"></span>No unprofessional doctors
                                                    </li>
                                                    <li class="sc_list_item" title="No poor quality products">
                                                        <span class="sc_list_icon icon-ok"></span>No poor quality products
                                                    </li>
                                                </ul>
                                                <a href="#" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_tiny margin_bottom_tiny bgc_5">More about us</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div id="sc_call_to_action_927" class="sc_call_to_action sc_call_to_action_accented sc_call_to_action_style_1 sc_call_to_action_align_center">
                                    <div class="sc_call_to_action_info">
                                        <h3 class="sc_call_to_action_title sc_item_title">High Innovative Technology & Professional Dentists</h3>
                                        <div class="sc_call_to_action_descr sc_item_descr">Make Appointment or call 8 800 254 25 64</div>
                                        <div class="sc_call_to_action_buttons sc_item_buttons">
                                            <div class="sc_call_to_action_button sc_item_button">
                                                <a href="appointment.html" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium">Make an Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width"></div>
                <div class="vc_row wpb_row vc_row-fluid">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div id="sc_form_761_wrap" class="sc_form_wrap">
                                    <div id="sc_form_761" class="sc_form sc_form_style_form_2 margin_top_huge margin_bottom_null">
                                        <h2 class="sc_form_title sc_item_title">Form for FREE Consultation</h2>
                                        <div class="sc_form_descr sc_item_descr">This is optional subheading</div>
                                        <form id="sc_form_761_form" data-formtype="form_2" method="post" action="includes/sendmail.php">
                                            <div class="sc_form_info">
                                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-user-light"></i>
                                                                    <label class="required" for="sc_form_username">Name</label>
                                                                    <input id="sc_form_username" type="text" name="username" placeholder="Name *">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-mobile-light"></i>
                                                                    <label class="required" for="sc_form_phone">Phone</label>
                                                                    <input id="sc_form_phone" type="text" name="phone" placeholder="Phone (Ex. +1-234-567-890)">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-mail-light"></i>
                                                                    <label class="required" for="sc_form_email">E-mail</label>
                                                                    <input id="sc_form_email" type="text" name="email" placeholder="E-mail *">
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-dentrario_add_user"></i>
                                                                    <label class="required" for="sc_form_doctor">Doctor</label>
                                                                    <input id="sc_form_doctor" type="text" name="doctor" placeholder="Doctor">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="sc_form_item sc_form_message label_over">
                                                <label class="required" for="sc_form_message">Message</label>
                                                <textarea id="sc_form_message" data-autoresize rows="1" name="message" placeholder="Message"></textarea>
                                            </div>
                                            <div class="sc_form_item sc_form_button">
                                                <button class="aligncenter">Make an Appointment</button>
                                            </div>
                                            <div class="result sc_infobox"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </article>
        <section class="related_wrap related_wrap_empty"></section>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>