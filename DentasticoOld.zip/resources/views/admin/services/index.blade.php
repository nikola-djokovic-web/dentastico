@extends('templates.admin.layout')

@section('seo-title')
<title>
    Usluge
    {{ config('app.seo-separator') }} {{ config('app.name') }}
</title>
@endsection


@section('plugins-css')
<!-- DataTables -->
<link rel="stylesheet" href="/templates/admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
@endsection

@section('custom-css')

@endsection

@section('content')
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Usluge
        </h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->

@include('templates.admin.partials.message')

<div class="row">

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Sve Usluge</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                    <div class="row">
                        <div class="col-sm-12">
                            @if(count($data) > 0)
                            <table width="100%" class="table table-striped table-bordered table-hover" id='services-table'>
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th>Image</th>
                                        <th>Title Sr</th>
                                        <th>Title En</th>
                                        <th class="text-center">Options</th>
                                    </tr>
                                </thead>
                                <tbody id="sortable">
                                    @foreach($data as $value)
                                    <tr id="{{ $value->id }}">
                                        <td class="text-center">{{$loop->iteration}}</td>
                                        <td><img style="height: 50px;" src='{{ $value->getImage('l') }}'></td>
                                        <td>{{ $value->title }}</td>
                                        <td>{{ $value->title2 }}</td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <a data-placement='top' data-original-title='Edit service' class="btn btn-xs btn-success" href='{{ route('services-edit', [ "service" => $value->id ]) }}'>Edit</a>

                                                @if($value->active == 0)
                                                <a data-button-title='Show' data-placement='top' data-original-title='show service {{ $value->title }}' class="btn btn-xs btn-warning" data-href='{{ route('services-active', [ "service" => $value->id ]) }}' data-toggle="modal" data-target="#myModal">Show</a>
                                                @else
                                                <a data-button-title='Hide' data-placement='top' data-original-title='hide service {{ $value->title }}' class="btn btn-xs btn-success" data-href='{{ route('services-active', [ "service" => $value->id ]) }}' data-toggle="modal" data-target="#myModal">Hide</a>
                                                @endif

                                                <button type='button' data-button-title='Delete' data-placement='top' data-original-title='delete service {{ $value->title }}' data-href="{{ route('services-delete', ["service" => $value->id]) }}" data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-danger">Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="text-left" style="margin: 10px;">
                            <a class="btn btn-primary btn-sm" href='{{route('services-create')}}'>Create new service</a>
                            </div>
                            @else
                            <div class="alert alert-warning">


                                There are no services in database!!!
                                <a href="{{ route('services-create') }}">Create new service</a>



                            </div>
                            @endif
                        </div></div><div class="row"><div class="col-sm-5"><div class="dataTables_info" id="services-table" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div></div><div class="col-sm-7"><div class="dataTables_paginate paging_simple_numbers" id="example2_paginate"><ul class="pagination"><li class="paginate_button previous disabled" id="example2_previous"><a href="#" aria-controls="example2" data-dt-idx="0" tabindex="0">Previous</a></li><li class="paginate_button active"><a href="#" aria-controls="example2" data-dt-idx="1" tabindex="0">1</a></li><li class="paginate_button "><a href="#" aria-controls="example2" data-dt-idx="2" tabindex="0">2</a></li><li class="paginate_button "><a href="#" aria-controls="example2" data-dt-idx="3" tabindex="0">3</a></li><li class="paginate_button "><a href="#" aria-controls="example2" data-dt-idx="4" tabindex="0">4</a></li><li class="paginate_button "><a href="#" aria-controls="example2" data-dt-idx="5" tabindex="0">5</a></li><li class="paginate_button "><a href="#" aria-controls="example2" data-dt-idx="6" tabindex="0">6</a></li><li class="paginate_button next" id="example2_next"><a href="#" aria-controls="example2" data-dt-idx="7" tabindex="0">Next</a></li></ul></div></div></div></div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->


        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->

</div>
</div>



<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete admin user</h4>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <a class="btn btn-action btn-danger">Delete</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>


@endsection

@section('plugins-js')
<!-- DataTables -->

@endsection

@section('custom-js')
<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script  type="text/javascript" charset="utf-8" src="https://code.jquery.com/jquery-3.3.1.js"></script>

<script  type="text/javascript" charset="utf-8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
      $('#myTable').DataTable( {
          columnDefs: [ {
              targets: [ 0 ],
              orderData: [ 0, 1 ]
          }, {
              targets: [ 1 ],
              orderData: [ 1, 0 ]
          }, {
              targets: [ 4 ],
              orderData: [ 4, 0 ]
          } ],

          order: [[ 4, "desc" ]]
      } );
    } );
</script>
<script>

$('#myModal').on('show.bs.modal', function (event) {

    var button = $(event.relatedTarget); // Button that triggered the modal
    var originalTitle = button.data('original-title'); // Extract info from data-* attributes

    //var userId = button.data('userid');
    var href = button.data('href');
    var buttonTitle = button.data('button-title');
    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
    var modal = $(this)
    modal.find('.modal-title').text(originalTitle);
    modal.find('.modal-body').text('Are you sure that you want to ' + originalTitle + '?')
    //modal.find('.modal-footer .btn-danger').attr('href', '/users/delete/' + userId);
    modal.find('.modal-footer .btn-action').attr('href', href);
    modal.find('.modal-footer .btn-action').text(buttonTitle);

    //modal.find('.modal-footer .btn-action').addClass();
})




$('table').tooltip({
    selector: "[data-placement=top]",
    container: "body"
})

</script>
@endsection
