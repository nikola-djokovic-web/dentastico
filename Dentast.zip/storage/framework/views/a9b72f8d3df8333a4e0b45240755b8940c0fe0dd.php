<header class="top_panel_wrap top_panel_style_2 scheme_original">
    <div class="top_panel_wrap_inner top_panel_inner_style_2 top_panel_position_above">
        <div class="top_panel_middle">
            <div class="content_wrap">
                <div class="columns_wrap columns_fluid">
                    <div class="column-1_3 contact_field contact_phone_wrap">
                      <div class="sc_socials sc_socials_type_icons sc_socials_shape_round sc_socials_size_small margin_bottom_small">
                            <div class="sc_socials_item">
                                <a href="https://twitter.com/dentastico" target="_blank" class="social_icons social_twitter">
                                    <span class="icon-twitter"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="https://www.facebook.com/Dentastico-107844797412293/" target="_blank" class="social_icons social_facebook">
                                    <span class="icon-facebook"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="https://www.instagram.com/dentastico.serbia/" target="_blank" class="social_icons social_instagram">
                                    <span class="icon-instagramm"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="mailto:office@dentastico.rs" target="_blank" class="social_icons social_facebook">
                                    <span class="icon-mail"></span>
                                </a>
                            </div>

                        </div>
                    </div>
                    <div class="column-1_3 contact_logo">
                        <div class="logo">
                            <a href="<?php echo e(route('homepage')); ?>">
                                <img src="/templates/frontend/images/logo-dent.png" class="logo_main" alt="Dentastico logo" width="202" height="49">
                            </a>
                        </div>
                    </div>
                    <div class="column-1_3 contact_field open_hours_wrap">
                      <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                          <div class="column-1_2 sc_column_item sc_column_item_1 odd first">

                              <div class="wpb_text_column wpb_content_element vc_custom_1454599782141">
                                  <div class="wpb_wrapper">
                                    <span class="contact_icon"><img style="margin-top: 3px;" src='/templates/frontend/images/viber.png'></span>
                                    <span class="text-left">+381 125 65 24</span>
                                    <span class="text-left">+381 125 65 24</span>
                                  </div>
                              </div>
                          </div>
                          <div class="column-1_2 sc_column_item sc_column_item_2 even">

                              <div class="wpb_text_column wpb_content_element vc_custom_1454599787135">
                                  <div class="wpb_wrapper" style="margin-top: 10px;">
                                    <div class="nav-wrapper">
                                      <div class="sl-nav">
                                        <!-- Sprache: -->
                                        <ul>
                                          <li><b>Language: <?php echo e(strtoupper(app()->getlocale())); ?></b> <i class="fa fa-angle-down" aria-hidden="true"></i>
                                            <div class="triangle"></div>
                                            <ul class="langs">
                                              <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li>
                                                  <a rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                                    <?php if($properties['native'] == 'Srpski'): ?>
                                                      <i class="sl-flag flag-sr"></i>
                                                    <?php elseif($properties['native'] == 'English'): ?>
                                                      <i class="sl-flag flag-uk"></i>
                                                    <?php elseif($properties['native'] == 'Italiano'): ?>
                                                      <i class="sl-flag flag-it"></i>
                                                    <?php endif; ?>

                                                      <?php echo e($properties['native']); ?>

                                                  </a>
                                                </li>

                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                          </li>
                                        </ul>
                                      </div>
                                    </div>
                                  </div>
                              </div>
                          </div>
                      </div>

                    </div>

                </div>
            </div>
        </div>
        <div class="top_panel_bottom">
            <div class="content_wrap clearfix">
                <nav class="menu_main_nav_area">
                    <ul id="menu_main" class="menu_main_nav">
                        <li class="menu-item <?php echo e(isActiveRoute('homepage')); ?>"><a href="<?php echo e(route('homepage')); ?>"><span><?php echo e(trans('front.home')); ?></span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('about')); ?>"><a href="<?php echo e(route('about')); ?>"><span><?php echo e(trans('front.about-us')); ?></span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('our-services')); ?>"><a href="<?php echo e(route('our-services')); ?>"><span><?php echo e(trans('front.our-services')); ?></span></a>
                        </li>
                        <li class="menu-item <?php echo e(isActiveRoute('services')); ?>"><a href="<?php echo e(route('services')); ?>"><span><?php echo e(trans('front.partners')); ?></span></a>
                        </li>

                        <li class="menu-item <?php echo e(isActiveRoute('contact')); ?>"><a href="<?php echo e(route('contact')); ?>"><span><?php echo e(trans('front.contact')); ?></span></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<div class="header_mobile">
    <div class="content_wrap">
        <div class="menu_button icon-menu"></div>
        <div class="logo">
            <a href="<?php echo e(route('homepage')); ?>">
                <img src="/templates/frontend/images/logo-dent.png" class="logo_main" alt="Dentastico logo" width="202" height="49">
            </a>

        </div>

    </div>
    <div class="side_wrap">
        <div class="close">Close</div>
        <div class="panel_top">
            <nav class="menu_main_nav_area">
                <ul id="menu_main_mobile" class="menu_main_nav">
                    <li class="menu-item <?php echo e(isActiveRoute('homepage')); ?>"><a href="<?php echo e(route('homepage')); ?>"><span><?php echo e(trans('front.home')); ?></span></a>
                    </li>
                    <li class="menu-item <?php echo e(isActiveRoute('about')); ?>"><a href="<?php echo e(route('about')); ?>"><span><?php echo e(trans('front.about-us')); ?></span></a>
                    </li>
                    <li class="menu-item <?php echo e(isActiveRoute('ourServices')); ?>"><a href="<?php echo e(route('our-services')); ?>"><span><?php echo e(trans('front.our-services')); ?></span></a>
                    </li>
                    <li class="menu-item <?php echo e(isActiveRoute('services')); ?>"><a href="<?php echo e(route('services')); ?>"><span><?php echo e(trans('front.services')); ?></span></a>
                    </li>
                    <li class="menu-item <?php echo e(isActiveRoute('contact')); ?>"><a href="<?php echo e(route('contact')); ?>"><span><?php echo e(trans('front.contact')); ?></span></a>
                    </li>
                    <li class="menu-item menu-item-has-children"><a href="#"><span class="open_child_menu"></span><span>Languages</span></a>
                        <ul class="sub-menu">
                          <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="menu-item"><a hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                              <?php if($properties['native'] == 'Srpski'): ?>
                                <i class="sl-flag flag-sr"></i>
                              <?php elseif($properties['native'] == 'English'): ?>
                                <i class="sl-flag flag-uk"></i>
                              <?php elseif($properties['native'] == 'Italiano'): ?>
                                <i class="sl-flag flag-it"></i>
                              <?php endif; ?>
                              <span style="margin-left: 10px;"><?php echo e($properties['native']); ?></span>
                              </a>
                            </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                </ul>
            </nav>

        </div>
        <div class="panel_bottom">
            <div class="contact_socials">
                <div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_small">
                    <div class="sc_socials_item">
                        <a href="https://twitter.com/dentastico" target="_blank" class="social_icons social_twitter">
                            <span class="icon-twitter"></span>
                        </a>
                    </div>

                    <div class="sc_socials_item">
                        <a href="https://www.facebook.com/Dentastico-107844797412293/" target="_blank" class="social_icons social_facebook">
                            <span class="icon-facebook"></span>
                        </a>
                    </div>
                    <div class="sc_socials_item">
                        <a href="https://www.instagram.com/dentastico.serbia/" target="_blank" class="social_icons social_instagramm">
                            <span class="icon-instagramm"></span>
                        </a>
                    </div>
                    <div class="sc_socials_item">
                        <a href="https://www.instagram.com/dentastico.serbia/" target="_blank" class="social_icons social_linkedin">
                            <span class="icon-linkedin"></span>
                        </a>
                    </div>
                    <div style="margin-bottom: 5px;">
                        office@dentastico.rs
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mask"></div>
</div>
