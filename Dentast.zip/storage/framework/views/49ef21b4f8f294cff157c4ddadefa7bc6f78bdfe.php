<?php $__env->startSection('seo-title'); ?>
    <title><?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="top_panel_title top_panel_style_2 title_present breadcrumbs_present scheme_original">
    <div class="top_panel_title_inner top_panel_inner_style_2 title_present_inner breadcrumbs_present_inner">
        <div class="content_wrap">
            <h1 class="page_title">Dentastico</h1>
            <div class="breadcrumbs">
                <a class="breadcrumbs_item home" href="index.html"><?php echo e(trans('front.home')); ?></a>
                <span class="breadcrumbs_delimiter"></span>
                <span class="breadcrumbs_item current">Dentastico</span>
            </div>
        </div>
    </div>
</div>
<div class="page_content_wrap page_paddings_yes">
    <div class="content_wrap">
        <div class="content">
            <article class="post_item post_item_404">
                <div class="post_content">
                    <div class="vc_empty_space space_32p">
                        <span class="vc_empty_space_inner"></span>
                    </div>
                    <h1 class="page_title">404</h1>
                    <h2 class="page_subtitle"><?php echo e(trans('front.requested-page')); ?></h2>
                    <p class="page_description"><?php echo e(trans('front.cant-find')); ?> <a href="<?php echo e(route('homepage')); ?>"><?php echo e(trans('front.home-btn')); ?></a>.</p>
                    <div class="aligncenter">
                        <a href="<?php echo e(route('homepage')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_null margin_bottom_null bgc_5"><?php echo e(trans('front.go-home')); ?></a>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>