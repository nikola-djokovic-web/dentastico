<?php $__env->startSection('seo-title'); ?>
<title>
    Usluge
    <?php echo e(config('app.seo-separator')); ?> <?php echo e(config('app.name')); ?>

</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('plugins-css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="/templates/admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
Vesti
        </h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->

<?php echo $__env->make('templates.admin.partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row">

    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Sve usluge</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(count($data) > 0): ?>
                            <table width="100%" class="table table-striped table-bordered table-hover" id='services-table'>
                                <thead>
                                    <tr>
                                        <th> # </th>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th class="text-center">Options</th>
                                    </tr>
                                </thead>
                                <tbody id="sortable">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="<?php echo e($value->id); ?>">
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><img style="height: 120px; width: 120px;" src='<?php echo e($value->getImage('xl')); ?>'></td>
                                        <td><?php echo e($value->title); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <a data-placement='top' data-original-title='Edit service' class="btn btn-xs btn-success" href='<?php echo e(route('services-edit', [ "service" => $value->id ])); ?>'>Edit</a>

                                                <?php if($value->active == 0): ?>
                                                <a data-button-title='Show' data-placement='top' data-original-title='show service <?php echo e($value->title); ?>' class="btn btn-xs btn-warning" data-href='<?php echo e(route('services-active', [ "service" => $value->id ])); ?>' data-toggle="modal" data-target="#myModal">Show</a>
                                                <?php else: ?>
                                                <a data-button-title='Hide' data-placement='top' data-original-title='hide service <?php echo e($value->title); ?>' class="btn btn-xs btn-success" data-href='<?php echo e(route('services-active', [ "service" => $value->id ])); ?>' data-toggle="modal" data-target="#myModal">Hide</a>
                                                <?php endif; ?>

                                                <button type='button' data-button-title='Delete' data-placement='top' data-original-title='delete service <?php echo e($value->title); ?>' data-href="<?php echo e(route('services-delete', ["service" => $value->id])); ?>" data-toggle="modal" data-target="#myModal" class="btn btn-xs btn-danger">Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="text-left" style="margin: 10px;">
                            <a class="btn btn-primary btn-sm" href='<?php echo e(route('services-create')); ?>'>Create new service</a>
                            </div>
                            <?php else: ?>
                            <div class="alert alert-warning">


                                There are no service in database!!!
                                <a href="<?php echo e(route('services-create')); ?>">Create new service</a>



                            </div>
                            <?php endif; ?>
                        </div>
                      </div>
                  </div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->


        <!-- /.box -->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->

</div>
</div>



<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Delete service</h4>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <a class="btn btn-action btn-danger">Delete</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins-js'); ?>
<!-- DataTables -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script src="/templates/admin/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/templates/admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script>
$(document).ready(function() {
    $('#services-table').DataTable({
        responsive: true,
        "columnDefs": [
            { "orderable": false, "targets": [0,2] },

        ]
    });
});

$('#myModal').on('show.bs.modal', function (event) {

    var button = $(event.relatedTarget); // Button that triggered the modal
    var originalTitle = button.data('original-title'); // Extract info from data-* attributes

    //var userId = button.data('userid');
    var href = button.data('href');
    var buttonTitle = button.data('button-title');
    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
    var modal = $(this)
    modal.find('.modal-title').text(originalTitle);
    modal.find('.modal-body').text('Are you sure that you want to ' + originalTitle + '?')
    //modal.find('.modal-footer .btn-danger').attr('href', '/users/delete/' + userId);
    modal.find('.modal-footer .btn-action').attr('href', href);
    modal.find('.modal-footer .btn-action').text(buttonTitle);

    //modal.find('.modal-footer .btn-action').addClass();
})




$('table').tooltip({
    selector: "[data-placement=top]",
    container: "body"
})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.master.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>