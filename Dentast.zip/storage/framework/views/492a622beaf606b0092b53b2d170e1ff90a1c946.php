<?php $__env->startSection('seo-title'); ?>
    <title><?php echo e(trans('front.home')); ?> <?php echo e(config('app.seo-separator')); ?> <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>
<style media="screen">
#message {
  position: absolute;
  bottom: 150px;
  right: 20px;
  z-index: 10;
}
</style>

<style media="screen">

[type="file"] {
  border: 0;
  clip: rect(0, 0, 0, 0);
  height: 1px;
  overflow: hidden;
  padding: 0;
  position: absolute !important;
  white-space: nowrap;
  width: 1px;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-slider'); ?>
<section class="slider_wrap slider_fullwide slider_engine_revo slider_alias_dentrario-home-3">
    <div id="rev_slider_2_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery">
        <div id="rev_slider_2_1" class="rev_slider fullwidthabanner" data-version="5.4.3">
            <ul>
                <li data-index="rs-6" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="1000" data-thumb="images/2640x1686.png" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <img src="/templates/frontend/images/doctors.jpg" alt="" title="home_3_sl2_bg" width="1920" height="517" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <div class="tp-caption dentrarario-home3-static-text tp-resizeme" id="slide-6-layer-2" data-x="35" data-y="320" data-width="['auto']" data-height="['auto']" data-visibility="['on','on','on','off']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];","speed":1500,"to":"o:1;","delay":400,"ease":"Power2.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        Keep your teeth and gums as healthy as possible
                        <br/> and keep visits to the dentist to a minimum.
                    </div>
                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" id="slide-6-layer-4" data-x="35" data-y="295" data-width="['76']" data-height="['1']" data-visibility="['on','on','on','off']" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"opacity:0;","speed":1500,"to":"o:1;","delay":400,"ease":"Power2.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                    </div>
                    <div class="tp-caption dentrarario-home3-static-header tp-resizeme" id="slide-6-layer-5" data-x="35" data-y="177" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1500,"to":"o:1;","delay":400,"ease":"Power3.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        High Innovative Technology
                        <br/> & Professional Dentists
                    </div>
                    <div class="tp-caption dentrarario-home3-appointment-btn tp-resizeme" id="slide-6-layer-6" data-x="35" data-y="center" data-voffset="160" data-width="['auto']" data-height="['auto']" data-visibility="['off','off','on','on']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];","speed":2000,"to":"o:1;","delay":400,"ease":"Power2.easeInOut"},{"delay":4350,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        <a href="<?php echo e(route('contact')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_small margin_bottom_small">Make an appointment</a>
                    </div>
                </li>
                <li data-index="rs-9" data-transition="fade,crossfade" data-slotamount="default,default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default,default" data-easeout="default,default" data-masterspeed="1000,default" data-thumb="images/2640x1686.png" data-rotate="0,0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <img src="/templates/frontend/images/2640x1686.png" alt="" title="home_3_sl1_bg" width="1920" height="517" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <div class="tp-caption dentrarario-home3-static-text tp-resizeme" id="slide-9-layer-2" data-x="35" data-y="320" data-width="['auto']" data-height="['auto']" data-visibility="['on','on','on','off']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1500,"to":"o:1;","delay":400,"ease":"Power3.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        Taking care of your general health, as well as your teeth,
                        <br/> is the key to a healthy mouth.
                    </div>
                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" id="slide-9-layer-4" data-x="35" data-y="295" data-width="['76']" data-height="['1']" data-visibility="['on','on','on','off']" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"opacity:0;","speed":1280,"to":"o:1;","delay":400,"ease":"Power2.easeInOut"},{"delay":5070,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                    </div>
                    <div class="tp-caption dentrarario-home3-static-header tp-resizeme" id="slide-9-layer-5" data-x="35" data-y="177" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1500,"to":"o:1;","delay":400,"ease":"Power3.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        High Innovative Technology
                        <br/> & Professional Dentists
                    </div>
                    <div class="tp-caption dentrarario-home3-appointment-btn tp-resizeme" id="slide-9-layer-6" data-x="35" data-y="center" data-voffset="160" data-width="['auto']" data-height="['auto']" data-visibility="['off','off','on','on']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;","speed":1500,"to":"o:1;","delay":400,"ease":"Power3.easeInOut"},{"delay":4850,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        <a href="<?php echo e(route('contact')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_small margin_bottom_small">Make an appointment</a>
                    </div>
                </li>
                <li data-index="rs-10" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="1000" data-thumb="images/2640x1686.png" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <img src="/templates/frontend/images/2640x1686.png" alt="" title="home_3_sl3_bg" width="1920" height="517" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <div class="tp-caption dentrarario-home3-static-text tp-resizeme" id="slide-10-layer-2" data-x="35" data-y="320" data-width="['auto']" data-height="['auto']" data-visibility="['on','on','on','off']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":400,"ease":"Power2.easeOut"},{"delay":5350,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        The most important part of preventive dentistry is to
                        <br/> brush teeth with fluoride toothpaste approved by ADA.
                    </div>
                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" id="slide-10-layer-4" data-x="35" data-y="295" data-width="['76']" data-height="['1']" data-visibility="['on','on','on','off']" data-type="shape" data-responsive_offset="on" data-frames='[{"from":"opacity:0;","speed":1280,"to":"o:1;","delay":400,"ease":"Power2.easeInOut"},{"delay":5070,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                    </div>
                    <div class="tp-caption dentrarario-home3-static-header tp-resizeme" id="slide-10-layer-5" data-x="35" data-y="177" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":400,"ease":"Power2.easeOut"},{"delay":5350,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        High Innovative Technology
                        <br/> & Professional Dentists
                    </div>
                    <div class="tp-caption dentrarario-home3-appointment-btn tp-resizeme" id="slide-10-layer-6" data-x="35" data-y="center" data-voffset="160" data-width="['auto']" data-height="['auto']" data-visibility="['off','off','on','on']" data-type="text" data-responsive_offset="on" data-frames='[{"from":"z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;","mask":"x:0px;y:0px;","speed":1000,"to":"o:1;","delay":400,"ease":"Power2.easeOut"},{"delay":5350,"speed":1000,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">
                        <a href="<?php echo e(route('contact')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_small margin_bottom_small">Make an appointment</a>
                    </div>
                </li>
            </ul>
            <div style="" class="tp-static-layers">
                <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme tp-static-layer" id="slider-2-layer-2" data-x="center" data-hoffset="" data-y="center" data-voffset="" data-width="['1000']" data-height="['full','full','full','full']" data-type="shape" data-responsive_offset="on" data-startslide="0" data-endslide="2" data-frames='[{"from":"opacity:0;","speed":300,"to":"o:1;","delay":500,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-captionhidden="on">
                </div>
                <div class="tp-caption dentrarario-home3-static-text slider_form tp-static-layer" id="slider-2-layer-3" data-x="center" data-hoffset="1" data-y="70" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-responsive="off" data-startslide="0" data-endslide="2" data-frames='[{"from":"opacity:0;","speed":300,"to":"o:1;","delay":500,"ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textAlign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-captionhidden="on">
                    <div id="sc_form_427_wrap" class="sc_form_wrap">

                        <div id="sc_form_427" class="sc_form sc_form_style_form_2">

                            <h2 class="sc_form_title sc_item_title"><?php echo e(trans('front.appointment')); ?></h2>
                            <div class="sc_form_descr sc_item_descr"></div>
                            <?php echo $__env->make('templates.frontend.partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <form id="sc_form_427_form" data-formtype="form_2" method="post" action="" class="inited" enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                                <div class="sc_form_info">
                                    <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                        <div class="column-1_2 sc_column_item sc_column_item_1">
                                            <div class="wpb_text_column wpb_content_element ">
                                                <div class="wpb_wrapper">
                                                    <div class="sc_form_item sc_form_field label_over"><i class="icon  icon-user-light"></i>
                                                        <label class="required" for="sc_form_username"><?php echo e(trans('front.name')); ?></label>
                                                        <input id="sc_form_username" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(trans("front.name")); ?> *" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_2 sc_column_item sc_column_item_2">
                                            <div class="wpb_text_column wpb_content_element ">
                                                <div class="wpb_wrapper">
                                                    <div class="sc_form_item sc_form_field label_over"><i class="icon icon-mobile-light"></i>
                                                        <label class="required" for="sc_form_phone"><?php echo e(trans('front.phone')); ?></label>
                                                        <input id="sc_form_phone" type="text" value="<?php echo e(old('phone')); ?>" name="phone" placeholder="<?php echo e(trans("front.phone")); ?> (Ex. +381-34-56-789)" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                        <div class="column-1_2 sc_column_item sc_column_item_1">
                                            <div class="wpb_text_column wpb_content_element ">
                                                <div class="wpb_wrapper">
                                                    <div class="sc_form_item sc_form_field label_over"><i class="icon icon-mail-light" style="margin-right: 5px;"></i>
                                                        <label class="required" for="sc_form_email"></label>
                                                        <input id="sc_form_email" type="text" value="<?php echo e(old('email')); ?>" name="email" placeholder="<?php echo e(trans("front.email")); ?> *" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_2 sc_column_item sc_column_item_2">
                                          <div class="" style="margin-top: 10px; margin-left: 10px;">
                                          </div>
                                          <input type="file" id="file" name="document">
                                          <label class="sc_button sc_button_square sc_button_style_filled sc_button_size_small margin_right_small bgc_5" for="file" />OPT snimak (opciono)</label>
                                        <div>
                                        </div>
                                    </div>
                                </div>
                                <div class="sc_form_item sc_form_message label_over">
                                    <label class="required" for="sc_form_message"><?php echo e(trans('front.message')); ?></label>
                                    <textarea id="sc_form_message" rows="1" name="message" placeholder="<?php echo e(trans("front.message")); ?> *" required><?php echo e(old('message')); ?></textarea>
                                </div>
                                <div class="sc_form_item sc_form_button">
                                    <button type="submit" class="aligncenter"><?php echo e(trans('front.appointment')); ?></button>
                                </div>
                                <div class="result sc_infobox"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tp-bannertimer"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="content_wrap">
  <div class="content">
      <article class="post_item post_item_single page hentry">
        <section class="post_content">
            <!-- <div class="vc_row wpb_row vc_row-fluid">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="vc_empty_space space_70p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <h2 class="sc_title sc_title_regular sc_align_center margin_bottom_null centext"><?php echo e(trans('front.welcome-to')); ?></h2>
                            <h6 class="vc_custom_heading vc_custom_1455116616738">We are ready to help you anytime</h6>
                            <div class="columns_wrap sc_columns columns_nofluid autoheight sc_columns_count_2">
                                <div class="column-1_2 sc_column_item sc_column_item_1">
                                    <div class="sc_column_item_inner bgimage_column"></div>
                                </div>
                                <div class="column-1_2 sc_column_item sc_column_item_2">
                                    <div class="vc_empty_space space_50p">
                                        <span class="vc_empty_space_inner"></span>
                                    </div>
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <p>
                                              <b><?php echo e(trans('front.mission')); ?></b> <?php echo e(trans('front.mission-d')); ?>


                                            </p>
                                            <p>
                                                <b><?php echo e(trans('front.vision')); ?></b> <?php echo e(trans('front.vision-d')); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(route('about')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium margin_top_small margin_bottom_small bgc_7"><?php echo e(trans('front.more-about')); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="vc_row wpb_row vc_row-fluid vc_custom_1449052136583">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="vc_empty_space space_30p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <div class="sc_section margin_bottom_large">
                                <div class="sc_section_inner">
                                    <h2 class="sc_title sc_title_underline sc_align_center cblack"><?php echo e(trans('front.welcome-to')); ?></h2>
                                    <div class="vc_empty_space space_5p">
                                        <span class="vc_empty_space_inner"></span>
                                    </div>
                                    <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2 margin_top_small">
                                        <div class="column-1_2 sc_column_item">
                                            <div class="wpb_text_column wpb_content_element ">
                                                <div class="wpb_wrapper">

                                                  <div class="sc_dropcaps sc_dropcaps_style_2">
                                                    <span class="sc_dropcaps_item" style="color: #a7c526;"><?php echo e(trans('front.mission')); ?></span><?php echo e(trans('front.mission-d')); ?>

                                                  </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_2 sc_column_item">
                                            <div class="wpb_text_column wpb_content_element ">
                                                <div class="wpb_wrapper">

                                                      <div class="sc_dropcaps sc_dropcaps_style_2">
                                                        <span class="sc_dropcaps_item"><?php echo e(trans('front.vision')); ?></span> <?php echo e(trans('front.vision-d')); ?>

                                                      </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="vc_empty_space space_40p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="columns_wrap sc_columns columns_fluid autoheight no_margins sc_columns_count_3">
                                <div class="column-1_4 sc_column_item sc_column_item_1">
                                    <div class="sc_column_item_inner bgc_1">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_269_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_269" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_269_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon "> <img src="/templates/frontend/images/1.png" alt=""> </span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Tooth Protection</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="column-1_4 sc_column_item sc_column_item_2">
                                    <div class="sc_column_item_inner bgc_2">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_260_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_260" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_260_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-12"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Teeth Whitening</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>Bleaching methods use carbamide peroxide which reacts with water to form hydrogen peroxide loremis</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="column-1_4 sc_column_item sc_column_item_3">
                                    <div class="sc_column_item_inner bgc_3">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_501_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_501" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_501_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-16"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Cosmetic Dentistry</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="column-1_4 sc_column_item sc_column_item_4">
                                    <div class="sc_column_item_inner bgc_1">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_269_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_269" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_269_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-3"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Tooth Protection</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="columns_wrap sc_columns columns_fluid autoheight no_margins sc_columns_count_3">
                                <div class="column-1_3 sc_column_item sc_column_item_1" style="height: 219px;">
                                    <div class="sc_column_item_inner bgc_1">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_269_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_269" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_269_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon "> <img src="/templates/frontend/images/1.png" alt=""> </span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Tooth Protection</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="column-1_3 sc_column_item sc_column_item_2" style="height: 219px;">
                                    <div class="sc_column_item_inner bgc_2">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_260_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_260" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_260_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-12"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Teeth Whitening</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>Bleaching methods use carbamide peroxide which reacts with water to form hydrogen peroxide loremis</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="column-1_3 sc_column_item sc_column_item_3" style="height: 219px;">
                                    <div class="sc_column_item_inner bgc_3">
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                        <div id="sc_services_501_wrap" class="sc_services_wrap sc_services_inverse">
                                            <div id="sc_services_501" class="sc_services sc_services_style_services-5 sc_services_type_icons">
                                                <div id="sc_services_501_1" class="sc_services_item sc_services_item_1">
                                                    <a href="single-service.html">
                                                        <span class="sc_icon icon-medic-16"></span>
                                                    </a>
                                                    <div class="sc_services_item_content">
                                                        <h4 class="sc_services_item_title">
                                                            <a href="single-service.html">Cosmetic Dentistry</a>
                                                        </h4>
                                                        <div class="sc_services_item_description">
                                                            <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                            <a href="single-service.html" class="sc_services_item_readmore">Learn more
                                                                <span class="icon-right"></span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="vc_empty_space hidden-xs space_32p">
                                            <span class="vc_empty_space_inner"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="vc_row-full-width">
            </div>

            <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1455704765009">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="vc_empty_space space_45p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <div id="sc_services_827_wrap" class="sc_services_wrap">
                                <div id="sc_services_827" class="sc_services sc_services_style_services-1 sc_services_type_icons margin_top_medium">
                                    <h2 class="sc_services_title sc_item_title"><?php echo e(trans('front.all-services')); ?></h2>
                                    <div class="sc_services_descr sc_item_descr">Services we provide</div>
                                    <div class="sc_columns columns_wrap">
                                        <div class="column-1_4 column_padding_bottom">
                                            <div id="sc_services_827_1" class="sc_services_item sc_services_item_1">
                                                <a href="single-service.html">
                                                    <span class="sc_icon icon-medic-1"></span>
                                                </a>
                                                <div class="sc_services_item_content">
                                                    <h4 class="sc_services_item_title">
                                                        <a href="<?php echo e(route('our-services')); ?>#contactus">Dental Implants</a>
                                                    </h4>
                                                    <div class="sc_services_item_description">
                                                        <p>The implant fixture is placed, so that it is likely to osseointegrate, then a dental prosthetic is added</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_4 column_padding_bottom">
                                            <div id="sc_services_827_2" class="sc_services_item sc_services_item_2">
                                                <a href="single-service.html">
                                                    <span class="sc_icon icon-medic-8"></span>
                                                </a>
                                                <div class="sc_services_item_content">
                                                    <h4 class="sc_services_item_title">
                                                        <a href="single-service.html">Dental Calculus</a>
                                                    </h4>
                                                    <div class="sc_services_item_description">
                                                        <p>Types of bridges may vary, depending upon how they are fabricated and the way they anchor to the adjacent teeth</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_4 column_padding_bottom">
                                            <div id="sc_services_827_3" class="sc_services_item sc_services_item_3">
                                                <a href="single-service.html">
                                                    <span class="sc_icon icon-medic-6"></span>
                                                </a>
                                                <div class="sc_services_item_content">
                                                    <h4 class="sc_services_item_title">
                                                        <a href="single-service.html">Prevention</a>
                                                    </h4>
                                                    <div class="sc_services_item_description">
                                                        <p>The most important part of preventive dentistry is to brush teeth with fluoride toothpaste approved by ADA</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_4 column_padding_bottom">
                                            <div id="sc_services_827_4" class="sc_services_item sc_services_item_4">
                                                <a href="single-service.html">
                                                    <span class="sc_icon icon-medic-16"></span>
                                                </a>
                                                <div class="sc_services_item_content">
                                                    <h4 class="sc_services_item_title">
                                                        <a href="single-service.html">Cosmetic Dentistry</a>
                                                    </h4>
                                                    <div class="sc_services_item_description">
                                                        <p>There are only 2 dental specialties that only focus on dental esthetics: Prosthodontics and Orthodontics</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="sc_services_button sc_item_button margin_top_tiny">
                                        <a href="/services" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium"><?php echo e(trans('front.view-services')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="vc_empty_space space_73p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row-full-width"></div>

            <div class="vc_row-full-width"></div>
            <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div id="sc_call_to_action_347" class="sc_call_to_action sc_call_to_action_accented sc_call_to_action_style_1 sc_call_to_action_align_center">
                                <div class="sc_call_to_action_info">
                                    <h3 class="sc_call_to_action_title sc_item_title"><?php echo e(trans('front.contact-dentastico')); ?></h3>
                                    <!-- <div class="sc_call_to_action_descr sc_item_descr">Make Appointment or call 8 800 254 25 64</div> -->
                                    <div class="sc_call_to_action_buttons sc_item_buttons">
                                        <div class="sc_call_to_action_button sc_item_button">
                                            <a href="<?php echo e(route('contact')); ?>" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium"><?php echo e(trans('front.appointment')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row-full-width"></div>
            <div class="vc_row wpb_row vc_row-fluid">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="vc_empty_space space_95p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <div id="sc_team_166_wrap" class="sc_team_wrap type1">
                                <div id="sc_team_166" class="sc_team sc_team_style_team-1 ">
                                    <h2 class="sc_team_title sc_item_title"><?php echo e(trans('front.meet-our-team')); ?></h2>
                                    <div class="sc_team_descr sc_item_descr"></div>
                                    <div class="sc_columns columns_wrap">
                                        <div class="column-1_2 column_padding_bottom">
                                            <div id="sc_team_166_1" class="sc_team_item">
                                                <div class="sc_team_item_avatar">
                                                    <img width="182" height="182" alt="" src="/templates/frontend/images/1000x1000.png">
                                                </div>
                                                <div class="sc_team_item_info">
                                                    <h5 class="sc_team_item_title">
                                                        <a href="single-team.html">Andrijana Kuzmanović</a>
                                                    </h5>
                                                    <div class="sc_team_item_position">Co-founder</div>
                                                    <div class="sc_team_item_description">
                                                        Andrijana Kuzmanović Types of bridges may vary, depending upon
                                                        how they are fabricated and the way they anchor to the adjacent teeth. Types...
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="column-1_2 column_padding_bottom">
                                            <div id="sc_team_166_2" class="sc_team_item">
                                                <div class="sc_team_item_avatar">
                                                    <img width="182" height="182" alt="" src="/templates/frontend/images/1000x1000.png">
                                                </div>
                                                <div class="sc_team_item_info">
                                                    <h5 class="sc_team_item_title">
                                                        <a href="single-team.html">Nenad Jevtović</a>
                                                    </h5>
                                                    <div class="sc_team_item_position">Co-founder</div>
                                                    <div class="sc_team_item_description">
                                                        Nenad Jevtović Types of bridges may vary, depending upon
                                                        how they are fabricated and the way they anchor to the adjacent teeth...
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="vc_empty_space space_72p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1452769085586">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner ">
                        <div class="wpb_wrapper">
                            <div class="vc_empty_space space_30p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                            <div id="sc_testimonials_550" class="sc_testimonials sc_testimonials_style_testimonials-1 sc_testimonials_inverse margin_top_large margin_bottom_huge">
                                <h2 class="sc_testimonials_title sc_item_title"><?php echo e(trans('front.our-happy-clients')); ?></h2>
                                <div class="sc_testimonials_descr sc_item_descr"></div>
                                <div class="sc_slider_swiper swiper-slider-container sc_slider_nopagination sc_slider_controls sc_slider_controls_side" data-interval="4844" data-slides-space="20" data-slides-min-width="250">
                                    <div class="slides swiper-wrapper">
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_1" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                        Svi iz Dentastika su super, a doktori odlični! Sve je prošlo kako treba. Pozdrav!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Jessica Smith</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_2" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                       Ljudi iz agencije Dentastiko su se potrudili da sve prođe kako treba. Zubi popravljeni a čitava usluga je jako povoljna. Pozdrav za sve u Beogradu!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Jenny Walker</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_3" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                      Agencija i stomatolozi odlično rade svoj posao. Vratila sam se kući sa puno lepih iskustava. Srbija je prelepa!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Dale Alvarado</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_3" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                      Agencija odlična a doktori jako stručni. Mnogo jeftinije nego u Austriji. Pozdrav iz Beča!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Dale Alvarado</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_3" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                      Od aerodroma, preko smeštaja do stomatološke ordinacije, sve je prošlo kako treba. Svi iz Dentastika su jako profesionalni. Imate moje preporuke!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Dale Alvarado</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_3" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                      Za mnogo manje novca nego u Italiji, imam lepši osmeh i par novih prijateljstava više. Pozdrav za sve u Dentastiku i vidimo se opet na proleće!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Dale Alvarado</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper-slide" data-style="width:100%;">
                                            <div id="sc_testimonials_550_3" class="sc_testimonial_item">

                                                <div class="sc_testimonial_content">
                                                    <p>
                                                      Sve je prošlo kako treba! Agencija i doktori povoljni i odlično rade svoj posao. Samo tako nastavite. Sve preporuke!
                                                    </p>
                                                </div>
                                                <div class="sc_testimonial_author">
                                                    <span class="sc_testimonial_author_name">Dale Alvarado</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="sc_slider_controls_wrap">
                                        <a class="sc_slider_prev" href="#"></a>
                                        <a class="sc_slider_next" href="#"></a>
                                    </div>
                                    <div class="sc_slider_pagination_wrap"></div>
                                </div>
                            </div>
                            <div class="vc_empty_space space_5p">
                                <span class="vc_empty_space_inner"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row-full-width"></div>


            <div class="vc_row-full-width"></div>
            <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid">

            </div>
            <div class="vc_row-full-width"></div>
        </section>
      </article>
      <section class="related_wrap related_wrap_empty"></section>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>