<?php $__env->startComponent('mail::message'); ?>
# Šalje: <?php echo e($data->email); ?>


#Poruka
<?php echo e($data['message']); ?>



Br. telefona: <?php echo e($data->phone); ?>

<br>
<br>
<?php if(($data->document) != ''): ?>
<a type='button' href='http://127.0.0.1:8000<?php echo e($data->document); ?>'>Dokument</a>
<?php endif; ?>

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
