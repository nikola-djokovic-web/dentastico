<?php $__env->startSection('seo-title'); ?>
<title>Edit service <?php echo e($service->title); ?> <?php echo e(config('app.seo-separator')); ?> <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2 class="page-header">Edit partner - <?php echo e($service->title); ?></h2>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
    <div class="col-lg-9">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form method="post" action="" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                                <label>Title</label>
                                <input class="form-control" type="text" name="title" value="<?php echo e(old('title', $service->title)); ?>">

                                <?php if($errors->has('title')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('title')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('title2') ? ' has-error' : ''); ?>">
                                <label>Title (English)</label>
                                <input class="form-control" type="text" name="title2" value="<?php echo e(old('title2', $service->title2)); ?>">

                                <?php if($errors->has('title2')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('title2')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('title3') ? ' has-error' : ''); ?>">
                                <label>Title (Italian)</label>
                                <input class="form-control" type="text" name="title3" value="<?php echo e(old('title3', $service->title3)); ?>">

                                <?php if($errors->has('title3')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('title3')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <label>Title (Italian)</label>
                                <input class="form-control" type="text" name="description" value="<?php echo e(old('description', $service->description)); ?>">

                                <?php if($errors->has('description')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('description')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                                <label>Content</label>
                                <textarea class="form-control" name="content"><?php echo old('content', $service->content); ?></textarea>

                                <?php if($errors->has('content')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('content')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('content2') ? ' has-error' : ''); ?>">
                                <label>Content (English)</label>
                                <textarea class="form-control" name="content2"><?php echo old('content2', $service->content2); ?></textarea>

                                <?php if($errors->has('content2')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('content2')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('content3') ? ' has-error' : ''); ?>">
                                <label>Content (Italian)</label>
                                <textarea class="form-control" name="content3"><?php echo old('content3', $service->content3); ?></textarea>

                                <?php if($errors->has('content3')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('content3')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Current image</label>
                                <img style="height: 100px;" src='<?php echo e($service->getImage("m")); ?>'>
                            </div>
                            <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                                <label>New image (if you want)</label>
                                <input type="file" name='image'>

                                <?php if($errors->has('image')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('image')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('gallery') ? ' has-error' : ''); ?>">
                                <label>New gallery for gallery (if you want)</label>
                                <input type="file" name='gallery[]' multiple>

                                <?php if($errors->has('gallery')): ?>
                                    <p class="help-block text-danger"><?php echo e($errors->first('gallery')); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group text-right">
                                <button class="btn btn-primary" type="submit">Edit service</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>
<script src="//cdn.ckeditor.com/4.10.0/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'content' );
    CKEDITOR.replace( 'content2' );
    CKEDITOR.replace( 'content3' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>