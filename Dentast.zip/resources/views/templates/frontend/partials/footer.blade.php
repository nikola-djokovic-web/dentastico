<footer class="footer_wrap widget_area scheme_dark">
    <div class="footer_wrap_inner widget_area_inner">
        <div class="content_wrap">
            <div class="columns_wrap">
                <aside class="column-1_2 widget widget_socials">
                    <div class="widget_inner">
                        <div class="logo">
                            <a href="index.html">
                                <img src="/templates/frontend/images/logo-dent-footer.png" class="logo_main" alt="Dentastico logo" width="168" height="42">
                            </a>
                        </div>
                        <div class="logo_descr">
                          <p>
                            <b>Misija</b> Dentastica je da klijentima pružimo najbrži i najlakši dolazak do stomatoloških usluga
                            širom Srbije, kao i da izgradimo odnose poverenja sa korisnicama naših usluga.

                          </p>
                          <p>
                              <b>Vizija</b> Dentastica je osmeh naših klijenata koji se osećaju sigurno da će dobiti najbolju stomatološku negu.
                          </p>

                        </div>
                        <div class="sc_socials sc_socials_type_icons sc_socials_shape_square sc_socials_size_tiny">
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_twitter">
                                    <span class="icon-twitter"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_gplus">
                                    <span class="icon-gplus"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_facebook">
                                    <span class="icon-facebook"></span>
                                </a>
                            </div>
                            <div class="sc_socials_item">
                                <a href="#" target="_blank" class="social_icons social_linkedin">
                                    <span class="icon-linkedin"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </aside>

                <aside class="column-1_2 widget widget_text">
                    <h5 class="widget_title">{{trans('front.contact-us')}}</h5>
                    @include('templates.partials.message')
                    <div class="textwidget">
                        <div id="sc_form_044_wrap" class="sc_form_wrap">
                            <div id="sc_form_044" class="sc_form sc_form_style_form_1 margin_top_null margin_bottom_null">
                              <form id="sc_form_329_form" data-formtype="form_2" method="post" action="{{route('contactF')}}" class="inited">
                                  @csrf
                                  <div class="sc_form_item sc_form_field label_over">
                                      <label class="required" for="sc_form_username">{{trans('front.name')}}</label>
                                      <input id="sc_form_username" type="text" name="name" value="{{old('name')}}" placeholder="{{trans("front.name")}} *" required>
                                  </div>
                                  <div class="sc_form_item sc_form_field label_over">
                                      <label class="required" for="sc_form_email"></label>
                                      <input id="sc_form_email" type="text" value="{{old('email')}}" name="email" placeholder="{{trans("front.email")}} *" required>
                                  </div>
                                  <div class="sc_form_item sc_form_message label_over">
                                    <label class="required" for="sc_form_message">{{trans('front.message')}}</label>
                                    <textarea id="sc_form_message" rows="1" name="message" placeholder="{{trans("front.message")}} *" required>{{old('message')}}</textarea>

                                  </div>
                                  <div class="sc_form_item sc_form_button">
                                      <button type="submit">{{trans('front.appointment')}}</button>
                                  </div>
                                  <div class="result sc_infobox"></div>
                              </form>

                            </div>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</footer>
