<?php

return [
	'about' 	=> 	'about-us',
	'services' 		=> 	'partners',
	'contact' 		=> 	'contact',
	'our-services' 		=> 	'services',

	// other translated routes
];
