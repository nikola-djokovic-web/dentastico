<?php

return [
	'about' 	=> 	'o-nama',
	'services' 		=> 	'partneri',
	'contact' 		=> 	'kontakt',
	'our-services' 		=> 	'usluge',

	// other translated routes
];
