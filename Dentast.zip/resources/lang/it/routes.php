<?php

return [
	'about' 	=> 	'chi-siamo',
	'services' 		=> 	'partners',
	'contact' 		=> 	'contatti',
	'our-services' 		=> 	'servizi',
	// other translated routes
];
