<?php
    return [
        'login' => 'Uloguj se',
        'sign-in' => 'Prijavi se',
        'forgot-password' => 'Zaboravljena lozinka',
        'logout'=> 'Odjavi se',
        'profile'=> 'Profil',
        'create-user' => 'Kreiraj novog korisnika',
        
    ];
?>