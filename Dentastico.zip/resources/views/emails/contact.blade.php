@component('mail::message')
# Šalje: {{$data['email']}}

The body of your message.

@component('mail::button', ['url' => ''])
{{$data['message']}}
@endcomponent

Br. telefona: {{$data['phone']}}
<br>
<br>
{{ config('app.name') }}
@endcomponent
