<script type='text/javascript' src='/templates/frontend/js/vendor/jquery/jquery.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/custom.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/jquery/fcc8474e79.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/esg/jquery.themepunch.tools.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/revslider/jquery.themepunch.revolution.min.js'></script>
<script type="text/javascript" src="/templates/frontend/js/vendor/revslider/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="/templates/frontend/js/vendor/revslider/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="/templates/frontend/js/vendor/revslider/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="/templates/frontend/js/vendor/revslider/extensions/revolution.extension.parallax.min.js"></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/modernizr.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/jquery/core.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/jquery/datepicker.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/superfish.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/jquery.slidemenu.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/core.utils.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/core.init.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/init.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/social-share.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/embed.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/shortcodes.js'></script>
<script type='text/javascript' src='/templates/frontend/js/custom/core.messages.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/comp/comp_front.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/swiper/swiper.min.js'></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/isotope/isotope.pkgd.min.js'></script>
<script type='text/javascript' src='http://maps.google.com/maps/api/js?key='></script>
<script type='text/javascript' src='/templates/frontend/js/vendor/core.googlemap.js'></script>

<script type="text/javascript">
<script type="text/javascript">
  $(document).ready(function() {
    setTimeout(function() {
    $('#message').fadeOut('fast');
}, 3000);
  });
</script>
