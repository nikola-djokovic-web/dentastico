
@extends('templates.frontend.layout')

@section('seo-title')
    <title>{{trans('front.contact')}} {{ config('app.seo-separator') }} {{ config('app.name') }}</title>
@endsection

@section('custom-css')

@endsection

@section('breadcrumbs')
<div class="top_panel_title top_panel_style_2 title_present breadcrumbs_present scheme_original">
                <div class="top_panel_title_inner top_panel_inner_style_2 title_present_inner breadcrumbs_present_inner">
                    <div class="content_wrap">
                        <h1 class="page_title">Contact Us</h1>
                        <div class="breadcrumbs">
                            <a class="breadcrumbs_item home" href="index.html">Home</a>
                            <span class="breadcrumbs_delimiter"></span>
                            <span class="breadcrumbs_item current">Contact Us</span>
                        </div>
                    </div>
                </div>
            </div>
@endsection
@section('content')
<div class="content">
                  <article class="post_item post_item_single page hentry">
                      <section class="post_content">
                          <div class="vc_row wpb_row vc_row-fluid">
                              <div class="wpb_column vc_column_container vc_col-sm-12">
                                  <div class="vc_column-inner ">
                                      <div class="wpb_wrapper">
                                        <!-- Horizontal Steppers -->
                                              <div class="row">
                                                <div class="col-md-12">

                                                  <!-- Stepers Wrapper -->
                                                  <ul class="stepper stepper-horizontal">

                                                    <!-- First Step -->
                                                    <li class="completed">
                                                      <a href="#!">
                                                        <span class="circle">1</span>
                                                        <span class="label">First step</span>
                                                      </a>
                                                    </li>

                                                    <!-- Second Step -->
                                                    <li class="active">
                                                      <a href="#!">
                                                        <span class="circle">2</span>
                                                        <span class="label">Second step</span>
                                                      </a>
                                                    </li>

                                                    <!-- Third Step -->
                                                    <li class="warning">
                                                      <a href="#!">
                                                        <span class="circle"><i class="fas fa-exclamation"></i></span>
                                                        <span class="label">Third step</span>
                                                      </a>
                                                    </li>

                                                  </ul>
                                                  <!-- /.Stepers Wrapper -->

                                                </div>
                                              </div>
                                              <!-- /.Horizontal Steppers -->


                                          <h2 class="sc_title sc_title_regular sc_align_center margin_top_huge margin_bottom_tiny centext">How To Find Us</h2>
                                          <h3 class="vc_custom_heading">Address and Direction</h3>
                                          <div class="columns_wrap sc_columns columns_nofluid autoheight sc_columns_count_2">
                                              <div class="column-1_2 sc_column_item centext">
                                                  <div class="sc_column_item_inner bgimage_column"></div>
                                              </div>
                                              <div id="sc_form_427_wrap" class="sc_form_wrap">
                                                  <div id="sc_form_427" class="sc_form sc_form_style_form_2">
                                                      <h2 class="sc_form_title sc_item_title">Get a Free Consultation</h2>
                                                      <div class="sc_form_descr sc_item_descr">You can contact us anytime</div>
                                                      @include('templates.partials.message')
                                                      <form id="sc_form_427_form" data-formtype="form_2" method="post" action="" class="inited">
                                                        @csrf
                                                          <div class="sc_form_info">
                                                              <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                                  <div class="column-1_2 sc_column_item sc_column_item_1">
                                                                      <div class="wpb_text_column wpb_content_element ">
                                                                          <div class="wpb_wrapper">
                                                                              <div class="sc_form_item sc_form_field label_over"><i class="icon  icon-user-light"></i>
                                                                                  <label class="required" for="sc_form_username">Name</label>
                                                                                  <input id="sc_form_username" type="text" name="name" placeholder="Name *">
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                  <div class="column-1_2 sc_column_item sc_column_item_2">
                                                                      <div class="wpb_text_column wpb_content_element ">
                                                                          <div class="wpb_wrapper">
                                                                              <div class="sc_form_item sc_form_field label_over"><i class="icon icon-mobile-light"></i>
                                                                                  <label class="required" for="sc_form_phone">Phone</label>
                                                                                  <input id="sc_form_phone" type="text" name="phone" placeholder="Phone (Ex. +1-234-567-890)">
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                              <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                                  <div class="column-1_2 sc_column_item sc_column_item_1">
                                                                      <div class="wpb_text_column wpb_content_element ">
                                                                          <div class="wpb_wrapper">
                                                                              <div class="sc_form_item sc_form_field label_over"><i class="icon icon-mail-light"></i>
                                                                                  <label class="required" for="sc_form_email">E-mail</label>
                                                                                  <input id="sc_form_email" type="text" name="email" placeholder="E-mail *">
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                                  <div class="column-1_2 sc_column_item sc_column_item_2">
                                                                      <div class="wpb_text_column wpb_content_element ">
                                                                          <div class="wpb_wrapper">
                                                                              <div class="sc_form_item sc_form_field label_over"><i class="icon icon-dentrario_add_user"></i>
                                                                                  <label class="required" for="sc_form_doctor">File</label>
                                                                                  <input id="sc_form_doctor" type="file" name="document" placeholder="Doctor">
                                                                              </div>
                                                                          </div>
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                          </div>
                                                          <div class="sc_form_item sc_form_message label_over">
                                                              <label class="required" for="sc_form_message">Message</label>
                                                              <textarea id="sc_form_message" rows="1" name="message" placeholder="Message"></textarea>
                                                          </div>
                                                          <div class="sc_form_item sc_form_button">
                                                              <button type="submit" class="aligncenter">Make an Appointment</button>
                                                          </div>
                                                          <div class="result sc_infobox"></div>
                                                      </form>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                              <div class="wpb_column vc_column_container vc_col-sm-12">
                                  <div class="vc_column-inner ">
                                      <div class="wpb_wrapper">
                                          <div id="sc_googlemap_961" class="sc_googlemap" data-zoom="16" data-style="ultra_light">
                                              <div id="sc_googlemap_961_1" class="sc_googlemap_marker" data-title="New York" data-description="&lt;div class=&quot;wpb_text_column wpb_content_element &quot; &gt; &lt;div class=&quot;wpb_wrapper&quot;&gt; &lt;p&gt;New York&lt;/p&gt;&lt;/div&gt;&lt;/div&gt;" data-address="New York" data-latlng="" data-point="images/map_marker.png"></div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="vc_row-full-width"></div>
                      </section>
                  </article>
                  <section class="related_wrap related_wrap_empty"></section>
              </div>


@endsection

@section('custom-js')

@endsection
