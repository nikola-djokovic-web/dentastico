@extends('templates.frontend.layout')


@section('seo-title')
    <title>{{trans('front.team')}} {{ config('app.seo-separator') }} {{ config('app.name') }}</title>
@endsection

@section('custom-css')

@endsection


@section('content')

<div id="page-submenu" class="page-submenu d-flex align-items-xl-center" data-local-scroll>
			<ul>
				<li><a href="#paulmolive">{{trans('front.dr')}} Dušanka Perišić</a></li>
				<li><a href="#annasthesia">{{trans('front.dr')}} Jelena Perišić</a></li>
				<li><a href="#mayadidas">{{trans('front.dr')}} Marko Perišić</a></li>


			</ul>
		</div>
<div id="content" class="page-ourteam">

			<section id="page-title-area" class="page-title-area d-flex align-items-end p-4">
        <div class="bg-image-holder"><img src="/templates/frontend/assets/img/drperisic/slider3.jpg" alt="page-title-bg"></div>
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-12">
							<h1 class="page-title">{{trans('front.team')}}</h1>
						</div>
						<div class="col-lg-12">
							<ol class="breadcrumbs d-flex align-items-center">
								<li>
									<a href="{{route('homepage')}}">{{trans('front.home')}}</a>
								</li>
								<li class="active">{{trans('front.team')}}</li>
							</ol>
						</div>
					</div><!-- /.row-->
				</div><!-- /.container-->
			</section>


			<section id="paulmolive" class="onepagesection odd p-6">
				<div class="container-custom">
					<div class="row">
						<div class="col-xl-6 col-lg-12">
							<figure>
								<img class="onepagesection-img" src="/templates/frontend/assets/img/drperisic/3.jpg" alt="dusankaperisic">
								<img class="dotted" src="/templates/frontend/assets/img/dotted-bg.png" alt="dotted">
							</figure>
						</div>
						<div class="col-xl-6 col-lg-12 pt-5">
							<div class="onepagesection-title">
								<h2>{{trans('front.dr')}} Dušanka Perišić</h2>
							</div>
							<div class="onepagesection-content">
								<h3>{{trans('front.team-d')}} </h3>
                <p>{{trans('front.team-dd')}} </p>
							</div>

						</div>
					</div><!-- /.row-->
				</div><!-- /.container-->
			</section>


			<section id="annasthesia" class="onepagesection even p-6">
				<div class="container-custom">
					<div class="row d-flex flex-xl-row-reverse">
						<div class="col-xl-6 col-lg-12">
							<figure>
								<img class="onepagesection-img" src="/templates/frontend/assets/img/drperisic/2.jpg" alt="jelenaperisic">
								<img class="dotted" src="/templates/frontend/assets/img/dotted-bg.png" alt="dotted">
							</figure>
						</div>
						<div class="col-xl-6 col-lg-12 pt-5">
							<div class="onepagesection-title">
								<h2>{{trans('front.dr')}} Jelena Perišić</h2>
							</div>
							<div class="onepagesection-content">
								<h3 class="text-right">{{trans('front.team-j')}}</h3>
                <p>{{trans('front.team-jd')}}</p>
							</div>

						</div>
					</div><!-- /.row-->
				</div><!-- /.container-->
			</section>


			<section id="mayadidas" class="onepagesection odd p-6">
				<div class="container-custom">
					<div class="row">
						<div class="col-xl-6 col-lg-12">
							<figure>
								<img class="onepagesection-img" src="/templates/frontend/assets/img/drperisic/1.jpg" alt="markoperisic">
								<img class="dotted" src="/templates/frontend/assets/img/dotted-bg.png" alt="dotted">
							</figure>
						</div>
						<div class="col-xl-6 col-lg-12 pt-5">
							<div class="onepagesection-title">
								<h2>{{trans('front.dr')}} Marko Perišić</h2>
							</div>
							<div class="onepagesection-content">
								<h3>{{trans('front.team-m')}}</h3>
                <p>{{trans('front.team-md')}} </p>
							</div>

						</div>
					</div><!-- /.row-->
				</div><!-- /.container-->
			</section>




@endsection








@section('custom-js')
@endsection
