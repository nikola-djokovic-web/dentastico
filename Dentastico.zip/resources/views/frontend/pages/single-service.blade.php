@extends('templates.frontend.layout')

@section('custom-css')

@endsection

@section('breadcrumbs')
<div class="top_panel_title top_panel_style_2 title_present breadcrumbs_present scheme_original">
    <div class="top_panel_title_inner top_panel_inner_style_2 title_present_inner breadcrumbs_present_inner">
        <div class="content_wrap">
            <h1 class="page_title">Dental Implants</h1>
            <div class="breadcrumbs">
                <a class="breadcrumbs_item home" href="{{route('homepage')}}">Home</a>
                <span class="breadcrumbs_delimiter"></span>
                <a class="breadcrumbs_item cat_post" href="{{route('services')}}">Main</a>
                <span class="breadcrumbs_delimiter"></span>
                <span class="breadcrumbs_item current">ime usluge</span>
            </div>
        </div>
    </div>
</div>
@endsection

@section('content')

      <div class="content">
        <article class="post_item post_item_single services hentry services_group-main services_group-small">
            <section class="post_content">
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2 margin_top_huge margin_bottom_huge">
                                    <div class="column-1_2 sc_column_item">
                                        <figure class="sc_image sc_image_shape_square">
                                            <img src="images/2640x1686.png" alt="Dentastico" />
                                        </figure>
                                    </div>
                                    <div class="column-1_2 sc_column_item">
                                        <h2 class="sc_title sc_title_regular margin_top_null">
                                            We eliminate the inconvenience<br /> of multiple visits
                                        </h2>
                                        <h6 class="sc_title sc_title_regular margin_top_null">POPULAR INFORMATION</h6>
                                        <div class="wpb_text_column wpb_content_element ">
                                            <div class="wpb_wrapper">
                                                <p>
                                                    Types of bridges may vary, depending upon how they are fabricated and the way they anchor to the adjacent teeth.
                                                    Types of bridges may vary, depending upon how they are fabricated and the way.
                                                </p>
                                                <p>They anchor to the adjacent teeth. Way they anchor to the adjacent teeth. Types of bridges may vary, depending upon how they are fabricated and the way.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div id="sc_call_to_action_303" class="sc_call_to_action sc_call_to_action_accented sc_call_to_action_style_1 sc_call_to_action_align_center">
                                    <div class="sc_call_to_action_info">
                                        <h3 class="sc_call_to_action_title sc_item_title">High Innovative Technology & Professional Dentists</h3>
                                        <div class="sc_call_to_action_descr sc_item_descr">Make Appointment or call 8 800 254 25 64</div>
                                        <div class="sc_call_to_action_buttons sc_item_buttons">
                                            <div class="sc_call_to_action_button sc_item_button">
                                                <a href="appointment.html" class="sc_button sc_button_square sc_button_style_filled sc_button_size_medium">Make an Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width"></div>
                <div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid scheme_light">
                    <div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner ">
                            <div class="wpb_wrapper">
                                <div id="sc_form_445_wrap" class="sc_form_wrap">
                                    <div id="sc_form_445" class="sc_form sc_form_style_form_2 margin_top_huge margin_bottom_huge">
                                        <h2 class="sc_form_title sc_item_title">Form for FREE Consultation</h2>
                                        <div class="sc_form_descr sc_item_descr">This is optional subheading</div>
                                        <form id="sc_form_445_form" data-formtype="form_2" method="post" action="includes/sendmail.php">
                                            <div class="sc_form_info">
                                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-user-light"></i>
                                                                    <label class="required" for="sc_form_username">Name</label>
                                                                    <input id="sc_form_username" type="text" name="username" placeholder="Name *">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-mobile-light"></i>
                                                                    <label class="required" for="sc_form_phone">Phone</label>
                                                                    <input id="sc_form_phone" type="text" name="phone" placeholder="Phone (Ex. +1-234-567-890)">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="columns_wrap sc_columns columns_nofluid sc_columns_count_2">
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-mail-light"></i>
                                                                    <label class="required" for="sc_form_email">E-mail</label>
                                                                    <input id="sc_form_email" type="text" name="email" placeholder="E-mail *">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="column-1_2 sc_column_item">
                                                        <div class="wpb_text_column wpb_content_element ">
                                                            <div class="wpb_wrapper">
                                                                <div class="sc_form_item sc_form_field label_over">
                                                                    <i class="icon icon-dentrario_add_user"></i>
                                                                    <label class="required" for="sc_form_doctor">Doctor</label>
                                                                    <input id="sc_form_doctor" type="text" name="doctor" placeholder="Doctor">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="sc_form_item sc_form_message label_over">
                                                <label class="required" for="sc_form_message">Message</label>
                                                <textarea id="sc_form_message" data-autoresize rows="1" name="message" placeholder="Message"></textarea>
                                            </div>
                                            <div class="sc_form_item sc_form_button">
                                                <button class="aligncenter">Make an Appointment</button>
                                            </div>
                                            <div class="result sc_infobox"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row-full-width"></div>
            </section>
        </article>
        <section class="related_wrap related_wrap_empty"></section>
    </div>

@endsection


@section('custom-js')

@endsection
