<?php

return [
	'about' 	=> 	'Chi siamo',
	'services' 		=> 	'Servizi',
	'contacts' 		=> 	'contatti',
	'' 		=> 	'',
	// other translated routes
];
