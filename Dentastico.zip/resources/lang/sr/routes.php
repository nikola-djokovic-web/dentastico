<?php

return [
	'about' 	=> 	'O nama',
	'services' 		=> 	'Usluge',
	'contacts' 		=> 	'Kontakt',
	'' 		=> 	'',

	// other translated routes
];
