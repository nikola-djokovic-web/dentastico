<?php
    return [
        'home' => "Početna",
        'about-us' => "O nama",
        'welcome' => "Dobrodošli",
        'enter-email' => "Dobijajte najnovije vesti putem email-a",
        'login' => 'Uloguj se',
        'sign-in' => 'Prijavi se',
        'forgot-password' => 'Zaboravljena lozinka',
        'search' => 'Pretraga',
        'open' => 'Otvori',
        'search-results' => 'Rezultati pretrage',
        'details' => 'Detaljnije',
        'go' => 'Traži!',
        'no-data' => 'Nažalost nema podataka u bazi za traženi pojam.',
        'submit' => 'Pošalji',
        'serbian' => 'Srpski',
        'english' => 'Engleski',
        'phone' => 'Telefon',

        'services' => 'Usluge',
        'contact' => 'Kontakt',
        'name' => 'Ime i prezime',
        'email' => 'E-mail',
        'message' => 'Poruka',
        'file' => 'Fajl',
        'appointment' => 'Zakažite termin',
        '' => '',
        '' => '',
        '' => '',
        'links' => 'Linkovi',
        'email-contact' => 'Kontaktirajte nas putem email-a',


    ];
?>
