<?php
return[
    'login' => 'Log in',
    'sign-in' => 'Sign In',
    'forgot-password' => 'I forgot my password',
    'logout'=> 'Sign out',
    'profile'=> 'Profile',
    'create-user' => 'Create new admin user',
  
];

