<?php

return [
	'about' 	=> 	'About us',
	'services' 		=> 	'Services',
	'contacts' 		=> 	'Contact',
	'' 		=> 	'',

	// other translated routes
];
