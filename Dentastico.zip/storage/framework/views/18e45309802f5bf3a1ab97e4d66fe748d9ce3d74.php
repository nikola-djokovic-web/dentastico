<?php $__env->startComponent('mail::message'); ?>
# Šalje: <?php echo e($data['email']); ?>


The body of your message.

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
<?php echo e($data['message']); ?>

<?php echo $__env->renderComponent(); ?>

Br. telefona: <?php echo e($data['phone']); ?>

<br>
<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
