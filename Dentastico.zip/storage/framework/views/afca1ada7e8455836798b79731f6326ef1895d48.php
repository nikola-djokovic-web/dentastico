<?php $__env->startSection('seo-title'); ?>
<title><?php echo e(trans('admin.login')); ?> <?php echo e(config('app.seo-separator')); ?> <?php echo e(config('app.name')); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="login-box">
  <div class="login-logo">
    <a href="<?php echo e(route('homepage')); ?>"><b>Admin</b>Dentastico</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg"><?php echo e(trans('admin.sign-in')); ?></p>

    <?php echo $__env->make('templates.admin.partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <form role='form' action="" method="post">
        <?php echo csrf_field(); ?>
      <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <input value='<?php echo e(old('email')); ?>' class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        <?php if($errors->has('email')): ?>
            <div class="alert alert-danger" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </div>
        <?php endif; ?>
      </div>
      <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <input type="password" class="form-control" name="password" placeholder="Password" value="">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        <?php if($errors->has('password')): ?>
            <div class="alert alert-danger" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </div>
        <?php endif; ?>
      </div>
      <div class="row">

        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block">Log in</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <!-- <a href="#"><?php echo e(trans('admin.forgot-password')); ?></a><br> -->

  </div>
  <!-- /.login-box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.login.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>