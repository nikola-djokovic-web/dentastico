<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Service;
use Intervention\Image\Facades\Image;

class ServicesController extends Controller
{
  public function index() {

      $data = Service::notdeleted()->get();

      return view('admin.services.index', compact('data'));
  }

  public function create() {

      if (request()->isMethod('post')) {
          $this->validate(request(), [
              'title' => 'required|string|max:191',
              'title2' => 'nullable|string|max:191',
              'title3' => 'nullable|string|max:191',
              'description' => 'nullable|string',
              'content' => 'required|string',
              'content2' => 'nullable|string',
              'content3' => 'nullable|string',
              'image' => 'required|mimes:jpeg,jpg,bmp,png',
          ]);

          $newRow = new Service();

          $newRow->title = request('title');
          $newRow->title2 = request('title2');
          $newRow->title3 = request('title3');
          $newRow->description = request('description');
          $newRow->content = request('content');
          $newRow->content2 = request('content2');
          $newRow->content3 = request('content3');
          $newRow->active = 0;
          $newRow->deleted = 0;


          $image = "";

          // check image element in request and accept image
          if (request()->hasFile('image')) {
              $file = request('image');
//                echo $file->getClientOriginalName();
//                echo $file->getClientOriginalExtension();

              $fileName = str_slug($newRow->title, '-');
              $extension = $file->getClientOriginalExtension();
              $fullFileName = config('app.seo-image-prefix') . $fileName . "." . $extension;

              $file->move(public_path('/uploads/services'), $fullFileName);
              $image = '/uploads/services/' . $fullFileName;

              // intervention
              // create image from original
              $intervetionImage = Image::make(public_path('/uploads/services/') . $fullFileName);
              // xl size
              $intervetionImage->resize(1000, null, function ($constraint) {
                  $constraint->aspectRatio();
              });
              $fullFileNameXL = config('app.seo-image-prefix') . $fileName . "-xl." . $extension;
              $intervetionImage->save(public_path('/uploads/services/') . $fullFileNameXL);

              // l size
              $intervetionImage->resize(450, null, function ($constraint) {
                  $constraint->aspectRatio();
              });
             $fullFileNameL =  config('app.seo-image-prefix') . $fileName . "-l." . $extension;
             $intervetionImage->save( public_path('/uploads/services/') . $fullFileNameL );

          }


          $newRow->image = $image;

          $newRow->save();

          // set message

          session()->flash('message-type', "success");
          session()->flash('message', "Service  $newRow->title has been created successfully!!!");

          return redirect( route('my-services') );
      }



      return view('admin.services.create');
  }

  public function edit(Service $service) {


      if (request()->isMethod('post')) {
          $this->validate(request(), [
              'title' => 'required|string|max:191',
              'title2' => 'string|max:191',
              'title3' => 'nullable|max:191',
              'description' => 'nullable',
              'content' => 'required|string',
              'content2' => 'nullable|string',
              'content3' => 'nullable|string',
              'image' => 'mimes:jpeg,jpg,bmp,png',
          ]);


          $service->title = request('title');
          $service->title2 = request('title2');
          $service->title3 = request('title3');
          $service->content = request('content');
          $service->content2 = request('content2');
          $service->content3 = request('content3');


          $image = $service->image;

          // check image element in request and accept image
          if (request()->hasFile('image')) {
              $file = request('image');
//                echo $file->getClientOriginalName();
//                echo $file->getClientOriginalExtension();

              $fileName = str_slug($service->title, '-');
              $extension = $file->getClientOriginalExtension();
              $fullFileName = config('app.seo-image-prefix') . $fileName . "." . $extension;

              $file->move(public_path('/uploads/service'), $fullFileName);
              $image = '/uploads/service/' . $fullFileName;

              // intervention
              // create image from original
              $intervetionImage = Image::make(public_path('/uploads/service/') . $fullFileName);
              // xl size
              $intervetionImage->resize(1000, null, function ($constraint) {
                  $constraint->aspectRatio();
              });
              $fullFileNameXL = config('app.seo-image-prefix') . $fileName . "-xl." . $extension;
              $intervetionImage->save(public_path('/uploads/service/') . $fullFileNameXL);

              // l size
              $intervetionImage->resize(450, null, function ($constraint) {
                  $constraint->aspectRatio();
              });
             $fullFileNameL =  config('app.seo-image-prefix') . $fileName . "-l." . $extension;
             $intervetionImage->save( public_path('/uploads/service/') . $fullFileNameL );


          }

          $service->image = $image;

          $service->save();

          // set message

          session()->flash('message-type', "success");
          session()->flash('message', "Service article $service->title has been edited successfully!!!");


//            session()->flash('message', [
//                'type' => 'success',
//                'text' => "User $newRow->name has been created successfully!!!"
//            ]);


          return redirect(route('my-services'));
      }

      return view('admin.services.edit', compact('service'));
  }

  public function activate(Service $services) {

      if ($services->active == 1) {
          $services->active = 0;
          $services->save();
      } else {
          $services->active = 1;
          $services->save();
      }

      // set message
      session()->flash('message-type', "success");
      session()->flash('message', "Service $services->title status updated successfully!!!");


      return redirect(route('my-services'));
  }

  public function delete(Service $service) {
      $service->deleted = 1;

      $service->save();

      // set message
      session()->flash('message-type', "success");
      session()->flash('message', "Service $service->title deleted successfully!!!");


      return redirect(route('my-services'));
  }
}
